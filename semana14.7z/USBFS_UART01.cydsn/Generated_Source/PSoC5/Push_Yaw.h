/*******************************************************************************
* File Name: Push_Yaw.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Push_Yaw_H) /* Pins Push_Yaw_H */
#define CY_PINS_Push_Yaw_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Push_Yaw_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Push_Yaw__PORT == 15 && ((Push_Yaw__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Push_Yaw_Write(uint8 value);
void    Push_Yaw_SetDriveMode(uint8 mode);
uint8   Push_Yaw_ReadDataReg(void);
uint8   Push_Yaw_Read(void);
void    Push_Yaw_SetInterruptMode(uint16 position, uint16 mode);
uint8   Push_Yaw_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Push_Yaw_SetDriveMode() function.
     *  @{
     */
        #define Push_Yaw_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Push_Yaw_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Push_Yaw_DM_RES_UP          PIN_DM_RES_UP
        #define Push_Yaw_DM_RES_DWN         PIN_DM_RES_DWN
        #define Push_Yaw_DM_OD_LO           PIN_DM_OD_LO
        #define Push_Yaw_DM_OD_HI           PIN_DM_OD_HI
        #define Push_Yaw_DM_STRONG          PIN_DM_STRONG
        #define Push_Yaw_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Push_Yaw_MASK               Push_Yaw__MASK
#define Push_Yaw_SHIFT              Push_Yaw__SHIFT
#define Push_Yaw_WIDTH              1u

/* Interrupt constants */
#if defined(Push_Yaw__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Push_Yaw_SetInterruptMode() function.
     *  @{
     */
        #define Push_Yaw_INTR_NONE      (uint16)(0x0000u)
        #define Push_Yaw_INTR_RISING    (uint16)(0x0001u)
        #define Push_Yaw_INTR_FALLING   (uint16)(0x0002u)
        #define Push_Yaw_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Push_Yaw_INTR_MASK      (0x01u) 
#endif /* (Push_Yaw__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Push_Yaw_PS                     (* (reg8 *) Push_Yaw__PS)
/* Data Register */
#define Push_Yaw_DR                     (* (reg8 *) Push_Yaw__DR)
/* Port Number */
#define Push_Yaw_PRT_NUM                (* (reg8 *) Push_Yaw__PRT) 
/* Connect to Analog Globals */                                                  
#define Push_Yaw_AG                     (* (reg8 *) Push_Yaw__AG)                       
/* Analog MUX bux enable */
#define Push_Yaw_AMUX                   (* (reg8 *) Push_Yaw__AMUX) 
/* Bidirectional Enable */                                                        
#define Push_Yaw_BIE                    (* (reg8 *) Push_Yaw__BIE)
/* Bit-mask for Aliased Register Access */
#define Push_Yaw_BIT_MASK               (* (reg8 *) Push_Yaw__BIT_MASK)
/* Bypass Enable */
#define Push_Yaw_BYP                    (* (reg8 *) Push_Yaw__BYP)
/* Port wide control signals */                                                   
#define Push_Yaw_CTL                    (* (reg8 *) Push_Yaw__CTL)
/* Drive Modes */
#define Push_Yaw_DM0                    (* (reg8 *) Push_Yaw__DM0) 
#define Push_Yaw_DM1                    (* (reg8 *) Push_Yaw__DM1)
#define Push_Yaw_DM2                    (* (reg8 *) Push_Yaw__DM2) 
/* Input Buffer Disable Override */
#define Push_Yaw_INP_DIS                (* (reg8 *) Push_Yaw__INP_DIS)
/* LCD Common or Segment Drive */
#define Push_Yaw_LCD_COM_SEG            (* (reg8 *) Push_Yaw__LCD_COM_SEG)
/* Enable Segment LCD */
#define Push_Yaw_LCD_EN                 (* (reg8 *) Push_Yaw__LCD_EN)
/* Slew Rate Control */
#define Push_Yaw_SLW                    (* (reg8 *) Push_Yaw__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Push_Yaw_PRTDSI__CAPS_SEL       (* (reg8 *) Push_Yaw__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Push_Yaw_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Push_Yaw__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Push_Yaw_PRTDSI__OE_SEL0        (* (reg8 *) Push_Yaw__PRTDSI__OE_SEL0) 
#define Push_Yaw_PRTDSI__OE_SEL1        (* (reg8 *) Push_Yaw__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Push_Yaw_PRTDSI__OUT_SEL0       (* (reg8 *) Push_Yaw__PRTDSI__OUT_SEL0) 
#define Push_Yaw_PRTDSI__OUT_SEL1       (* (reg8 *) Push_Yaw__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Push_Yaw_PRTDSI__SYNC_OUT       (* (reg8 *) Push_Yaw__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Push_Yaw__SIO_CFG)
    #define Push_Yaw_SIO_HYST_EN        (* (reg8 *) Push_Yaw__SIO_HYST_EN)
    #define Push_Yaw_SIO_REG_HIFREQ     (* (reg8 *) Push_Yaw__SIO_REG_HIFREQ)
    #define Push_Yaw_SIO_CFG            (* (reg8 *) Push_Yaw__SIO_CFG)
    #define Push_Yaw_SIO_DIFF           (* (reg8 *) Push_Yaw__SIO_DIFF)
#endif /* (Push_Yaw__SIO_CFG) */

/* Interrupt Registers */
#if defined(Push_Yaw__INTSTAT)
    #define Push_Yaw_INTSTAT            (* (reg8 *) Push_Yaw__INTSTAT)
    #define Push_Yaw_SNAP               (* (reg8 *) Push_Yaw__SNAP)
    
	#define Push_Yaw_0_INTTYPE_REG 		(* (reg8 *) Push_Yaw__0__INTTYPE)
#endif /* (Push_Yaw__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Push_Yaw_H */


/* [] END OF FILE */
