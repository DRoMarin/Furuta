/*******************************************************************************
* File Name: Qd_Pitch_PM.c
* Version 3.0
*
* Description:
*  This file contains the setup, control and status commands to support 
*  component operations in low power mode.  
*
* Note:
*  None.
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Qd_Pitch.h"

static Qd_Pitch_BACKUP_STRUCT Qd_Pitch_backup = {0u};


/*******************************************************************************
* Function Name: Qd_Pitch_SaveConfig
********************************************************************************
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Qd_Pitch_SaveConfig(void) 
{
    #if (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_8_BIT)
        Qd_Pitch_Cnt8_SaveConfig();
    #else 
        /* (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_16_BIT) || 
         * (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_32_BIT)
         */
        Qd_Pitch_Cnt16_SaveConfig();
    #endif /* (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_8_BIT) */
}


/*******************************************************************************
* Function Name: Qd_Pitch_RestoreConfig
********************************************************************************
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Qd_Pitch_RestoreConfig(void) 
{
    #if (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_8_BIT)
        Qd_Pitch_Cnt8_RestoreConfig();
    #else 
        /* (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_16_BIT) || 
         * (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_32_BIT) 
         */
        Qd_Pitch_Cnt16_RestoreConfig();
    #endif /* (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_8_BIT) */
}


/*******************************************************************************
* Function Name: Qd_Pitch_Sleep
********************************************************************************
* 
* Summary:
*  Prepare Quadrature Decoder Component goes to sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Qd_Pitch_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Qd_Pitch_Sleep(void) 
{
    if (0u != (Qd_Pitch_SR_AUX_CONTROL & Qd_Pitch_INTERRUPTS_ENABLE))
    {
        Qd_Pitch_backup.enableState = 1u;
    }
    else /* The Quadrature Decoder Component is disabled */
    {
        Qd_Pitch_backup.enableState = 0u;
    }

    Qd_Pitch_Stop();
    Qd_Pitch_SaveConfig();
}


/*******************************************************************************
* Function Name: Qd_Pitch_Wakeup
********************************************************************************
*
* Summary:
*  Prepare Quadrature Decoder Component to wake up.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Qd_Pitch_backup - used when non-retention registers are restored.
*
*******************************************************************************/
void Qd_Pitch_Wakeup(void) 
{
    Qd_Pitch_RestoreConfig();

    if (Qd_Pitch_backup.enableState != 0u)
    {
        #if (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_8_BIT)
            Qd_Pitch_Cnt8_Enable();
        #else 
            /* (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_16_BIT) || 
            *  (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_32_BIT) 
            */
            Qd_Pitch_Cnt16_Enable();
        #endif /* (Qd_Pitch_COUNTER_SIZE == Qd_Pitch_COUNTER_SIZE_8_BIT) */

        /* Enable component's operation */
        Qd_Pitch_Enable();
    } /* Do nothing if component's block was disabled before */
}


/* [] END OF FILE */

