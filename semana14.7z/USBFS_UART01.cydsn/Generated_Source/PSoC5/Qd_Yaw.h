/*******************************************************************************
* File Name: Qd_Yaw.h  
* Version 3.0
*
* Description:
*  This file provides constants and parameter values for the Quadrature
*  Decoder component.
*
* Note:
*  None.
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_QUADRATURE_DECODER_Qd_Yaw_H)
#define CY_QUADRATURE_DECODER_Qd_Yaw_H

#include "cyfitter.h"
#include "CyLib.h"
#include "cytypes.h"

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component QuadDec_v3_0 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#define Qd_Yaw_COUNTER_SIZE               (16u)
#define Qd_Yaw_COUNTER_SIZE_8_BIT         (8u)
#define Qd_Yaw_COUNTER_SIZE_16_BIT        (16u)
#define Qd_Yaw_COUNTER_SIZE_32_BIT        (32u)

#if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT)
    #include "Qd_Yaw_Cnt8.h"
#else 
    /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT) || 
    *  (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT) 
    */
    #include "Qd_Yaw_Cnt16.h"
#endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT */

extern uint8 Qd_Yaw_initVar;


/***************************************
*   Conditional Compilation Parameters
***************************************/

#define Qd_Yaw_COUNTER_RESOLUTION         (4u)


/***************************************
*       Data Struct Definition
***************************************/

/* Sleep Mode API Support */
typedef struct
{
    uint8 enableState;
} Qd_Yaw_BACKUP_STRUCT;


/***************************************
*        Function Prototypes
***************************************/

void  Qd_Yaw_Init(void) ;
void  Qd_Yaw_Start(void) ;
void  Qd_Yaw_Stop(void) ;
void  Qd_Yaw_Enable(void) ;
uint8 Qd_Yaw_GetEvents(void) ;
void  Qd_Yaw_SetInterruptMask(uint8 mask) ;
uint8 Qd_Yaw_GetInterruptMask(void) ;
int16 Qd_Yaw_GetCounter(void) ;
void  Qd_Yaw_SetCounter(int16 value)
;
void  Qd_Yaw_Sleep(void) ;
void  Qd_Yaw_Wakeup(void) ;
void  Qd_Yaw_SaveConfig(void) ;
void  Qd_Yaw_RestoreConfig(void) ;

#if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
    CY_ISR_PROTO(Qd_Yaw_ISR);
#endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT */


/***************************************
*           API Constants
***************************************/

#if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
    #define Qd_Yaw_ISR_NUMBER             ((uint8) Qd_Yaw_isr__INTC_NUMBER)
    #define Qd_Yaw_ISR_PRIORITY           ((uint8) Qd_Yaw_isr__INTC_PRIOR_NUM)
#endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT */


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define Qd_Yaw_GLITCH_FILTERING           (1u)
#define Qd_Yaw_INDEX_INPUT                (0u)


/***************************************
*    Initial Parameter Constants
***************************************/

#if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT)
    #define Qd_Yaw_COUNTER_INIT_VALUE    (0x80u)
#else 
    /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT) ||
    *  (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
    */
    #define Qd_Yaw_COUNTER_INIT_VALUE    (0x8000u)
    #define Qd_Yaw_COUNTER_MAX_VALUE     (0x7FFFu)
#endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT */


/***************************************
*             Registers
***************************************/

#define Qd_Yaw_STATUS_REG                 (* (reg8 *) Qd_Yaw_bQuadDec_Stsreg__STATUS_REG)
#define Qd_Yaw_STATUS_PTR                 (  (reg8 *) Qd_Yaw_bQuadDec_Stsreg__STATUS_REG)
#define Qd_Yaw_STATUS_MASK                (* (reg8 *) Qd_Yaw_bQuadDec_Stsreg__MASK_REG)
#define Qd_Yaw_STATUS_MASK_PTR            (  (reg8 *) Qd_Yaw_bQuadDec_Stsreg__MASK_REG)
#define Qd_Yaw_SR_AUX_CONTROL             (* (reg8 *) Qd_Yaw_bQuadDec_Stsreg__STATUS_AUX_CTL_REG)
#define Qd_Yaw_SR_AUX_CONTROL_PTR         (  (reg8 *) Qd_Yaw_bQuadDec_Stsreg__STATUS_AUX_CTL_REG)


/***************************************
*        Register Constants
***************************************/

#define Qd_Yaw_COUNTER_OVERFLOW_SHIFT     (0x00u)
#define Qd_Yaw_COUNTER_UNDERFLOW_SHIFT    (0x01u)
#define Qd_Yaw_COUNTER_RESET_SHIFT        (0x02u)
#define Qd_Yaw_INVALID_IN_SHIFT           (0x03u)
#define Qd_Yaw_COUNTER_OVERFLOW           ((uint8) (0x01u << Qd_Yaw_COUNTER_OVERFLOW_SHIFT))
#define Qd_Yaw_COUNTER_UNDERFLOW          ((uint8) (0x01u << Qd_Yaw_COUNTER_UNDERFLOW_SHIFT))
#define Qd_Yaw_COUNTER_RESET              ((uint8) (0x01u << Qd_Yaw_COUNTER_RESET_SHIFT))
#define Qd_Yaw_INVALID_IN                 ((uint8) (0x01u << Qd_Yaw_INVALID_IN_SHIFT))

#define Qd_Yaw_INTERRUPTS_ENABLE_SHIFT    (0x04u)
#define Qd_Yaw_INTERRUPTS_ENABLE          ((uint8)(0x01u << Qd_Yaw_INTERRUPTS_ENABLE_SHIFT))
#define Qd_Yaw_INIT_INT_MASK              (0x0Fu)


/******************************************************************************************
* Following code are OBSOLETE and must not be used starting from Quadrature Decoder 2.20
******************************************************************************************/
#define Qd_Yaw_DISABLE                    (0x00u)


#endif /* CY_QUADRATURE_DECODER_Qd_Yaw_H */


/* [] END OF FILE */
