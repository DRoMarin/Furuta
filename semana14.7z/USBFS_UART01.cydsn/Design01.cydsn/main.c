#include "project.h"
#include "cyapicallbacks.h"
#include "stdbool.h"
#include "stdio.h"
//#include "usbuartio.h"    
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

   float ek = 0; //error
    volatile float ik = 0; //accion integral y de memoria
    volatile float dk = 0; //accion integral y de memoria
    float KP = 8.99;
    float KI = 6.46;
    float KD = 2.56;
    float acc = 0.0;
    float mk = 0.0;   //accion de control
    float posicion = 0.0;
    float posicion1 = 0.0;
    float pwm=100.0;

    #define REFERENCE  0.0
    #define MAXINTEGRAL    4.7 //antiwindup de 4.7V
    #define PWM_FACTOR 1.0
    #define PWM_MAX 1024.0
    float ikl = 0.0;
    ADC_DelSig_1_Start();
    ADC_DelSig_1_StartConvert();
    PWM_1_Start();
    LCD_Start();
    LCD_ClearDisplay();
    int valorADC;
    float val;
    char impr[10];
    char impr2[10];
    while (1) { //es un placeholder
        valorADC=ADC_DelSig_1_Read16();
        posicion = (-1.8)*valorADC+320.0;
        if ((posicion<0.0)){
            posicion=320+(40-posicion*-1.0);
        }
        if ((posicion>270.0)){
            posicion=360-posicion;
        }
            
        if (valorADC>178) {
    	    //data=data*-1;
            Control_Reg_1_Write(0);
        }else{
             Control_Reg_1_Write(1);
            }
        
    	/* Determina el error e inicia el cálculo del regulador PI _D */
    	ek = REFERENCE - posicion;
    	/* Porción integral, ikl es la integral atrasada un periodo */
    	ik = KI * ek + ikl;
    	/* Porción derivada, posicion1 es la salida atrasada un periodo */
    	dk = KD * (posicion - posicion1);
    	/* Acción total de control, el signo negativo es para realimentación negativa */
    	acc = KP * ek + ik - dk;
    	/* Escribe en el buffer mk del PWM que será actualizado sincrónicamente */
    	mk = acc;
        mk=(mk*-1);
        /*Escalar el pwm*/
        pwm = (int16) (mk*PWM_FACTOR);
        //pwm=127;
        
        if (pwm > PWM_MAX) { 
                pwm = PWM_MAX;
            }
            else if (pwm < 0) {
                pwm = 0; 
            }
        if ((posicion<270)&&(posicion>90)){
            pwm=0;        
        }
        PWM_1_WriteCompare(pwm);
        LCD_Position(0,0);
        sprintf(impr2,"%f__",pwm);
        LCD_PrintString(impr2);
        LCD_Position(1,0);
        sprintf(impr,"%f__",mk);
        LCD_PrintString(impr);
        
    	/* Guarda la salida para la siguiente vez */
    	posicion1 = posicion;
    	ikl = ik;
    	/* Satura el término integral y lo guarda para la próxima vez */
    	if (ik > MAXINTEGRAL)
    		ikl = MAXINTEGRAL;
    	else
    		if (ik < -MAXINTEGRAL) ikl = -MAXINTEGRAL;
        }
        //delay(1000);
    }


/* [] END OF FILE */