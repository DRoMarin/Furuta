/*******************************************************************************
* File Name: AngEncoder.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_AngEncoder_H) /* Pins AngEncoder_H */
#define CY_PINS_AngEncoder_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "AngEncoder_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 AngEncoder__PORT == 15 && ((AngEncoder__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    AngEncoder_Write(uint8 value);
void    AngEncoder_SetDriveMode(uint8 mode);
uint8   AngEncoder_ReadDataReg(void);
uint8   AngEncoder_Read(void);
void    AngEncoder_SetInterruptMode(uint16 position, uint16 mode);
uint8   AngEncoder_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the AngEncoder_SetDriveMode() function.
     *  @{
     */
        #define AngEncoder_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define AngEncoder_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define AngEncoder_DM_RES_UP          PIN_DM_RES_UP
        #define AngEncoder_DM_RES_DWN         PIN_DM_RES_DWN
        #define AngEncoder_DM_OD_LO           PIN_DM_OD_LO
        #define AngEncoder_DM_OD_HI           PIN_DM_OD_HI
        #define AngEncoder_DM_STRONG          PIN_DM_STRONG
        #define AngEncoder_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define AngEncoder_MASK               AngEncoder__MASK
#define AngEncoder_SHIFT              AngEncoder__SHIFT
#define AngEncoder_WIDTH              1u

/* Interrupt constants */
#if defined(AngEncoder__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in AngEncoder_SetInterruptMode() function.
     *  @{
     */
        #define AngEncoder_INTR_NONE      (uint16)(0x0000u)
        #define AngEncoder_INTR_RISING    (uint16)(0x0001u)
        #define AngEncoder_INTR_FALLING   (uint16)(0x0002u)
        #define AngEncoder_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define AngEncoder_INTR_MASK      (0x01u) 
#endif /* (AngEncoder__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define AngEncoder_PS                     (* (reg8 *) AngEncoder__PS)
/* Data Register */
#define AngEncoder_DR                     (* (reg8 *) AngEncoder__DR)
/* Port Number */
#define AngEncoder_PRT_NUM                (* (reg8 *) AngEncoder__PRT) 
/* Connect to Analog Globals */                                                  
#define AngEncoder_AG                     (* (reg8 *) AngEncoder__AG)                       
/* Analog MUX bux enable */
#define AngEncoder_AMUX                   (* (reg8 *) AngEncoder__AMUX) 
/* Bidirectional Enable */                                                        
#define AngEncoder_BIE                    (* (reg8 *) AngEncoder__BIE)
/* Bit-mask for Aliased Register Access */
#define AngEncoder_BIT_MASK               (* (reg8 *) AngEncoder__BIT_MASK)
/* Bypass Enable */
#define AngEncoder_BYP                    (* (reg8 *) AngEncoder__BYP)
/* Port wide control signals */                                                   
#define AngEncoder_CTL                    (* (reg8 *) AngEncoder__CTL)
/* Drive Modes */
#define AngEncoder_DM0                    (* (reg8 *) AngEncoder__DM0) 
#define AngEncoder_DM1                    (* (reg8 *) AngEncoder__DM1)
#define AngEncoder_DM2                    (* (reg8 *) AngEncoder__DM2) 
/* Input Buffer Disable Override */
#define AngEncoder_INP_DIS                (* (reg8 *) AngEncoder__INP_DIS)
/* LCD Common or Segment Drive */
#define AngEncoder_LCD_COM_SEG            (* (reg8 *) AngEncoder__LCD_COM_SEG)
/* Enable Segment LCD */
#define AngEncoder_LCD_EN                 (* (reg8 *) AngEncoder__LCD_EN)
/* Slew Rate Control */
#define AngEncoder_SLW                    (* (reg8 *) AngEncoder__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define AngEncoder_PRTDSI__CAPS_SEL       (* (reg8 *) AngEncoder__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define AngEncoder_PRTDSI__DBL_SYNC_IN    (* (reg8 *) AngEncoder__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define AngEncoder_PRTDSI__OE_SEL0        (* (reg8 *) AngEncoder__PRTDSI__OE_SEL0) 
#define AngEncoder_PRTDSI__OE_SEL1        (* (reg8 *) AngEncoder__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define AngEncoder_PRTDSI__OUT_SEL0       (* (reg8 *) AngEncoder__PRTDSI__OUT_SEL0) 
#define AngEncoder_PRTDSI__OUT_SEL1       (* (reg8 *) AngEncoder__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define AngEncoder_PRTDSI__SYNC_OUT       (* (reg8 *) AngEncoder__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(AngEncoder__SIO_CFG)
    #define AngEncoder_SIO_HYST_EN        (* (reg8 *) AngEncoder__SIO_HYST_EN)
    #define AngEncoder_SIO_REG_HIFREQ     (* (reg8 *) AngEncoder__SIO_REG_HIFREQ)
    #define AngEncoder_SIO_CFG            (* (reg8 *) AngEncoder__SIO_CFG)
    #define AngEncoder_SIO_DIFF           (* (reg8 *) AngEncoder__SIO_DIFF)
#endif /* (AngEncoder__SIO_CFG) */

/* Interrupt Registers */
#if defined(AngEncoder__INTSTAT)
    #define AngEncoder_INTSTAT            (* (reg8 *) AngEncoder__INTSTAT)
    #define AngEncoder_SNAP               (* (reg8 *) AngEncoder__SNAP)
    
	#define AngEncoder_0_INTTYPE_REG 		(* (reg8 *) AngEncoder__0__INTTYPE)
#endif /* (AngEncoder__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_AngEncoder_H */


/* [] END OF FILE */
