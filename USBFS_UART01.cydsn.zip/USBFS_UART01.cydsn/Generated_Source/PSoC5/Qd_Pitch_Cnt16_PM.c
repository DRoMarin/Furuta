/*******************************************************************************
* File Name: Qd_Pitch_Cnt16_PM.c  
* Version 3.0
*
*  Description:
*    This file provides the power management source code to API for the
*    Counter.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Qd_Pitch_Cnt16.h"

static Qd_Pitch_Cnt16_backupStruct Qd_Pitch_Cnt16_backup;


/*******************************************************************************
* Function Name: Qd_Pitch_Cnt16_SaveConfig
********************************************************************************
* Summary:
*     Save the current user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Qd_Pitch_Cnt16_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void Qd_Pitch_Cnt16_SaveConfig(void) 
{
    #if (!Qd_Pitch_Cnt16_UsingFixedFunction)

        Qd_Pitch_Cnt16_backup.CounterUdb = Qd_Pitch_Cnt16_ReadCounter();

        #if(!Qd_Pitch_Cnt16_ControlRegRemoved)
            Qd_Pitch_Cnt16_backup.CounterControlRegister = Qd_Pitch_Cnt16_ReadControlRegister();
        #endif /* (!Qd_Pitch_Cnt16_ControlRegRemoved) */

    #endif /* (!Qd_Pitch_Cnt16_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Qd_Pitch_Cnt16_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Qd_Pitch_Cnt16_backup:  Variables of this global structure are used to 
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Qd_Pitch_Cnt16_RestoreConfig(void) 
{      
    #if (!Qd_Pitch_Cnt16_UsingFixedFunction)

       Qd_Pitch_Cnt16_WriteCounter(Qd_Pitch_Cnt16_backup.CounterUdb);

        #if(!Qd_Pitch_Cnt16_ControlRegRemoved)
            Qd_Pitch_Cnt16_WriteControlRegister(Qd_Pitch_Cnt16_backup.CounterControlRegister);
        #endif /* (!Qd_Pitch_Cnt16_ControlRegRemoved) */

    #endif /* (!Qd_Pitch_Cnt16_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Qd_Pitch_Cnt16_Sleep
********************************************************************************
* Summary:
*     Stop and Save the user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Qd_Pitch_Cnt16_backup.enableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Qd_Pitch_Cnt16_Sleep(void) 
{
    #if(!Qd_Pitch_Cnt16_ControlRegRemoved)
        /* Save Counter's enable state */
        if(Qd_Pitch_Cnt16_CTRL_ENABLE == (Qd_Pitch_Cnt16_CONTROL & Qd_Pitch_Cnt16_CTRL_ENABLE))
        {
            /* Counter is enabled */
            Qd_Pitch_Cnt16_backup.CounterEnableState = 1u;
        }
        else
        {
            /* Counter is disabled */
            Qd_Pitch_Cnt16_backup.CounterEnableState = 0u;
        }
    #else
        Qd_Pitch_Cnt16_backup.CounterEnableState = 1u;
        if(Qd_Pitch_Cnt16_backup.CounterEnableState != 0u)
        {
            Qd_Pitch_Cnt16_backup.CounterEnableState = 0u;
        }
    #endif /* (!Qd_Pitch_Cnt16_ControlRegRemoved) */
    
    Qd_Pitch_Cnt16_Stop();
    Qd_Pitch_Cnt16_SaveConfig();
}


/*******************************************************************************
* Function Name: Qd_Pitch_Cnt16_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Qd_Pitch_Cnt16_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Qd_Pitch_Cnt16_Wakeup(void) 
{
    Qd_Pitch_Cnt16_RestoreConfig();
    #if(!Qd_Pitch_Cnt16_ControlRegRemoved)
        if(Qd_Pitch_Cnt16_backup.CounterEnableState == 1u)
        {
            /* Enable Counter's operation */
            Qd_Pitch_Cnt16_Enable();
        } /* Do nothing if Counter was disabled before */    
    #endif /* (!Qd_Pitch_Cnt16_ControlRegRemoved) */
    
}


/* [] END OF FILE */
