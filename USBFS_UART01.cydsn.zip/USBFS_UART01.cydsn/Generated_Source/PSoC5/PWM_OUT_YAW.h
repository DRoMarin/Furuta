/*******************************************************************************
* File Name: PWM_OUT_YAW.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PWM_OUT_YAW_H) /* Pins PWM_OUT_YAW_H */
#define CY_PINS_PWM_OUT_YAW_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PWM_OUT_YAW_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 PWM_OUT_YAW__PORT == 15 && ((PWM_OUT_YAW__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    PWM_OUT_YAW_Write(uint8 value);
void    PWM_OUT_YAW_SetDriveMode(uint8 mode);
uint8   PWM_OUT_YAW_ReadDataReg(void);
uint8   PWM_OUT_YAW_Read(void);
void    PWM_OUT_YAW_SetInterruptMode(uint16 position, uint16 mode);
uint8   PWM_OUT_YAW_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the PWM_OUT_YAW_SetDriveMode() function.
     *  @{
     */
        #define PWM_OUT_YAW_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define PWM_OUT_YAW_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define PWM_OUT_YAW_DM_RES_UP          PIN_DM_RES_UP
        #define PWM_OUT_YAW_DM_RES_DWN         PIN_DM_RES_DWN
        #define PWM_OUT_YAW_DM_OD_LO           PIN_DM_OD_LO
        #define PWM_OUT_YAW_DM_OD_HI           PIN_DM_OD_HI
        #define PWM_OUT_YAW_DM_STRONG          PIN_DM_STRONG
        #define PWM_OUT_YAW_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define PWM_OUT_YAW_MASK               PWM_OUT_YAW__MASK
#define PWM_OUT_YAW_SHIFT              PWM_OUT_YAW__SHIFT
#define PWM_OUT_YAW_WIDTH              1u

/* Interrupt constants */
#if defined(PWM_OUT_YAW__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in PWM_OUT_YAW_SetInterruptMode() function.
     *  @{
     */
        #define PWM_OUT_YAW_INTR_NONE      (uint16)(0x0000u)
        #define PWM_OUT_YAW_INTR_RISING    (uint16)(0x0001u)
        #define PWM_OUT_YAW_INTR_FALLING   (uint16)(0x0002u)
        #define PWM_OUT_YAW_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define PWM_OUT_YAW_INTR_MASK      (0x01u) 
#endif /* (PWM_OUT_YAW__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PWM_OUT_YAW_PS                     (* (reg8 *) PWM_OUT_YAW__PS)
/* Data Register */
#define PWM_OUT_YAW_DR                     (* (reg8 *) PWM_OUT_YAW__DR)
/* Port Number */
#define PWM_OUT_YAW_PRT_NUM                (* (reg8 *) PWM_OUT_YAW__PRT) 
/* Connect to Analog Globals */                                                  
#define PWM_OUT_YAW_AG                     (* (reg8 *) PWM_OUT_YAW__AG)                       
/* Analog MUX bux enable */
#define PWM_OUT_YAW_AMUX                   (* (reg8 *) PWM_OUT_YAW__AMUX) 
/* Bidirectional Enable */                                                        
#define PWM_OUT_YAW_BIE                    (* (reg8 *) PWM_OUT_YAW__BIE)
/* Bit-mask for Aliased Register Access */
#define PWM_OUT_YAW_BIT_MASK               (* (reg8 *) PWM_OUT_YAW__BIT_MASK)
/* Bypass Enable */
#define PWM_OUT_YAW_BYP                    (* (reg8 *) PWM_OUT_YAW__BYP)
/* Port wide control signals */                                                   
#define PWM_OUT_YAW_CTL                    (* (reg8 *) PWM_OUT_YAW__CTL)
/* Drive Modes */
#define PWM_OUT_YAW_DM0                    (* (reg8 *) PWM_OUT_YAW__DM0) 
#define PWM_OUT_YAW_DM1                    (* (reg8 *) PWM_OUT_YAW__DM1)
#define PWM_OUT_YAW_DM2                    (* (reg8 *) PWM_OUT_YAW__DM2) 
/* Input Buffer Disable Override */
#define PWM_OUT_YAW_INP_DIS                (* (reg8 *) PWM_OUT_YAW__INP_DIS)
/* LCD Common or Segment Drive */
#define PWM_OUT_YAW_LCD_COM_SEG            (* (reg8 *) PWM_OUT_YAW__LCD_COM_SEG)
/* Enable Segment LCD */
#define PWM_OUT_YAW_LCD_EN                 (* (reg8 *) PWM_OUT_YAW__LCD_EN)
/* Slew Rate Control */
#define PWM_OUT_YAW_SLW                    (* (reg8 *) PWM_OUT_YAW__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PWM_OUT_YAW_PRTDSI__CAPS_SEL       (* (reg8 *) PWM_OUT_YAW__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PWM_OUT_YAW_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PWM_OUT_YAW__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PWM_OUT_YAW_PRTDSI__OE_SEL0        (* (reg8 *) PWM_OUT_YAW__PRTDSI__OE_SEL0) 
#define PWM_OUT_YAW_PRTDSI__OE_SEL1        (* (reg8 *) PWM_OUT_YAW__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PWM_OUT_YAW_PRTDSI__OUT_SEL0       (* (reg8 *) PWM_OUT_YAW__PRTDSI__OUT_SEL0) 
#define PWM_OUT_YAW_PRTDSI__OUT_SEL1       (* (reg8 *) PWM_OUT_YAW__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PWM_OUT_YAW_PRTDSI__SYNC_OUT       (* (reg8 *) PWM_OUT_YAW__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(PWM_OUT_YAW__SIO_CFG)
    #define PWM_OUT_YAW_SIO_HYST_EN        (* (reg8 *) PWM_OUT_YAW__SIO_HYST_EN)
    #define PWM_OUT_YAW_SIO_REG_HIFREQ     (* (reg8 *) PWM_OUT_YAW__SIO_REG_HIFREQ)
    #define PWM_OUT_YAW_SIO_CFG            (* (reg8 *) PWM_OUT_YAW__SIO_CFG)
    #define PWM_OUT_YAW_SIO_DIFF           (* (reg8 *) PWM_OUT_YAW__SIO_DIFF)
#endif /* (PWM_OUT_YAW__SIO_CFG) */

/* Interrupt Registers */
#if defined(PWM_OUT_YAW__INTSTAT)
    #define PWM_OUT_YAW_INTSTAT            (* (reg8 *) PWM_OUT_YAW__INTSTAT)
    #define PWM_OUT_YAW_SNAP               (* (reg8 *) PWM_OUT_YAW__SNAP)
    
	#define PWM_OUT_YAW_0_INTTYPE_REG 		(* (reg8 *) PWM_OUT_YAW__0__INTTYPE)
#endif /* (PWM_OUT_YAW__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_PWM_OUT_YAW_H */


/* [] END OF FILE */
