/*******************************************************************************
* File Name: Qd_Yaw.c  
* Version 3.0
*
* Description:
*  This file provides the source code to the API for the Quadrature Decoder
*  component.
*
* Note:
*  None.
*   
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Qd_Yaw.h"

#if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
    #include "Qd_Yaw_PVT.h"
#endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT */

uint8 Qd_Yaw_initVar = 0u;


/*******************************************************************************
* Function Name: Qd_Yaw_Init
********************************************************************************
*
* Summary:
*  Inits/Restores default QuadDec configuration provided with customizer.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Qd_Yaw_Init(void) 
{
    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
        /* Disable Interrupt. */
        CyIntDisable(Qd_Yaw_ISR_NUMBER);
        /* Set the ISR to point to the Qd_Yaw_isr Interrupt. */
        (void) CyIntSetVector(Qd_Yaw_ISR_NUMBER, & Qd_Yaw_ISR);
        /* Set the priority. */
        CyIntSetPriority(Qd_Yaw_ISR_NUMBER, Qd_Yaw_ISR_PRIORITY);
    #endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT */
}


/*******************************************************************************
* Function Name: Qd_Yaw_Enable
********************************************************************************
*
* Summary:
*  This function enable interrupts from Component and also enable Component's
*  ISR in case of 32-bit counter.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Qd_Yaw_Enable(void) 
{
    uint8 enableInterrupts;

    Qd_Yaw_SetInterruptMask(Qd_Yaw_INIT_INT_MASK);

    /* Clear pending interrupts. */
    (void) Qd_Yaw_GetEvents();
    
    enableInterrupts = CyEnterCriticalSection();

    /* Enable interrupts from Statusi register */
    Qd_Yaw_SR_AUX_CONTROL |= Qd_Yaw_INTERRUPTS_ENABLE;

    CyExitCriticalSection(enableInterrupts);        

    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
        /* Enable Component interrupts */
        CyIntEnable(Qd_Yaw_ISR_NUMBER);
    #endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT */
}


/*******************************************************************************
* Function Name: Qd_Yaw_Start
********************************************************************************
*
* Summary:
*  Initializes UDBs and other relevant hardware.
*  Resets counter, enables or disables all relevant interrupts.
*  Starts monitoring the inputs and counting.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  Qd_Yaw_initVar - used to check initial configuration, modified on
*  first function call.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Qd_Yaw_Start(void) 
{
    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT)
        Qd_Yaw_Cnt8_Start();
        Qd_Yaw_Cnt8_WriteCounter(Qd_Yaw_COUNTER_INIT_VALUE);
    #else
        /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT) || 
        *  (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT) 
        */
        Qd_Yaw_Cnt16_Start();
        Qd_Yaw_Cnt16_WriteCounter(Qd_Yaw_COUNTER_INIT_VALUE);
    #endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT */
    
    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)        
       Qd_Yaw_count32SoftPart = 0;
    #endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT */

    if (Qd_Yaw_initVar == 0u)
    {
        Qd_Yaw_Init();
        Qd_Yaw_initVar = 1u;
    }

    Qd_Yaw_Enable();
}


/*******************************************************************************
* Function Name: Qd_Yaw_Stop
********************************************************************************
*
* Summary:
*  Turns off UDBs and other relevant hardware.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Qd_Yaw_Stop(void) 
{
    uint8 enableInterrupts;

    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT)
        Qd_Yaw_Cnt8_Stop();
    #else 
        /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT) ||
        *  (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
        */
        Qd_Yaw_Cnt16_Stop();    /* counter disable */
    #endif /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT) */
 
    enableInterrupts = CyEnterCriticalSection();

    /* Disable interrupts interrupts from Statusi register */
    Qd_Yaw_SR_AUX_CONTROL &= (uint8) (~Qd_Yaw_INTERRUPTS_ENABLE);

    CyExitCriticalSection(enableInterrupts);

    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
        CyIntDisable(Qd_Yaw_ISR_NUMBER);    /* interrupt disable */
    #endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT */
}


/*******************************************************************************
* Function Name: Qd_Yaw_GetCounter
********************************************************************************
*
* Summary:
*  Reports the current value of the counter.
*
* Parameters:
*  None.
*
* Return:
*  The counter value. Return type is signed and per the counter size setting.
*  A positive value indicates clockwise movement (B before A).
*
* Global variables:
*  Qd_Yaw_count32SoftPart - used to get hi 16 bit for current value
*  of the 32-bit counter, when Counter size equal 32-bit.
*
*******************************************************************************/
int16 Qd_Yaw_GetCounter(void) 
{
    int16 count;
    uint16 tmpCnt;

    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
        int16 hwCount;

        CyIntDisable(Qd_Yaw_ISR_NUMBER);

        tmpCnt = Qd_Yaw_Cnt16_ReadCounter();
        hwCount = (int16) ((int32) tmpCnt - (int32) Qd_Yaw_COUNTER_INIT_VALUE);
        count = Qd_Yaw_count32SoftPart + hwCount;

        CyIntEnable(Qd_Yaw_ISR_NUMBER);
    #else 
        /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT) || 
        *  (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT)
        */
        #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT)
            tmpCnt = Qd_Yaw_Cnt8_ReadCounter();
        #else /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT) */
            tmpCnt = Qd_Yaw_Cnt16_ReadCounter();
        #endif  /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT */

        count = (int16) ((int32) tmpCnt -
                (int32) Qd_Yaw_COUNTER_INIT_VALUE);

    #endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT */ 

    return (count);
}


/*******************************************************************************
* Function Name: Qd_Yaw_SetCounter
********************************************************************************
*
* Summary:
*  Sets the current value of the counter.
*
* Parameters:
*  value:  The new value. Parameter type is signed and per the counter size
*  setting.
*
* Return:
*  None.
*
* Global variables:
*  Qd_Yaw_count32SoftPart - modified to set hi 16 bit for current
*  value of the 32-bit counter, when Counter size equal 32-bit.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Qd_Yaw_SetCounter(int16 value) 
{
    #if ((Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT) || \
         (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT))
        uint16 count;
        
        if (value >= 0)
        {
            count = (uint16) value + Qd_Yaw_COUNTER_INIT_VALUE;
        }
        else
        {
            count = Qd_Yaw_COUNTER_INIT_VALUE - (uint16)(-value);
        }
        #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT)
            Qd_Yaw_Cnt8_WriteCounter(count);
        #else /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT) */
            Qd_Yaw_Cnt16_WriteCounter(count);
        #endif  /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT */
    #else /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT) */
        CyIntDisable(Qd_Yaw_ISR_NUMBER);

        Qd_Yaw_Cnt16_WriteCounter(Qd_Yaw_COUNTER_INIT_VALUE);
        Qd_Yaw_count32SoftPart = value;

        CyIntEnable(Qd_Yaw_ISR_NUMBER);
    #endif  /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT) ||
             * (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT)
             */
}


/*******************************************************************************
* Function Name: Qd_Yaw_GetEvents
********************************************************************************
* 
* Summary:
*   Reports the current status of events. This function clears the bits of the 
*   status register.
*
* Parameters:
*  None.
*
* Return:
*  The events, as bits in an unsigned 8-bit value:
*    Bit      Description
*     0        Counter overflow.
*     1        Counter underflow.
*     2        Counter reset due to index, if index input is used.
*     3        Invalid A, B inputs state transition.
*
*******************************************************************************/
uint8 Qd_Yaw_GetEvents(void) 
{
    return (Qd_Yaw_STATUS_REG & Qd_Yaw_INIT_INT_MASK);
}


/*******************************************************************************
* Function Name: Qd_Yaw_SetInterruptMask
********************************************************************************
*
* Summary:
*  Enables / disables interrupts due to the events.
*  For the 32-bit counter, the overflow, underflow and reset interrupts cannot
*  be disabled, these bits are ignored.
*
* Parameters:
*  mask: Enable / disable bits in an 8-bit value, where 1 enables the interrupt.
*
* Return:
*  None.
*
*******************************************************************************/
void Qd_Yaw_SetInterruptMask(uint8 mask) 
{
    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
        /* Underflow, Overflow and Reset interrupts for 32-bit Counter are always enable */
        mask |= (Qd_Yaw_COUNTER_OVERFLOW | Qd_Yaw_COUNTER_UNDERFLOW |
                 Qd_Yaw_COUNTER_RESET);
    #endif /* Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT */

    Qd_Yaw_STATUS_MASK = mask;
}


/*******************************************************************************
* Function Name: Qd_Yaw_GetInterruptMask
********************************************************************************
*
* Summary:
*  Reports the current interrupt mask settings.
*
* Parameters:
*  None.
*
* Return:
*  Enable / disable bits in an 8-bit value, where 1 enables the interrupt.
*  For the 32-bit counter, the overflow, underflow and reset enable bits are
*  always set.
*
*******************************************************************************/
uint8 Qd_Yaw_GetInterruptMask(void) 
{
    return (Qd_Yaw_STATUS_MASK & Qd_Yaw_INIT_INT_MASK);
}


/* [] END OF FILE */
