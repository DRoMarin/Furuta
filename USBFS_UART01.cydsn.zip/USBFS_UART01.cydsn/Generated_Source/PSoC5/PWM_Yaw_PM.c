/*******************************************************************************
* File Name: PWM_Yaw_PM.c
* Version 3.30
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "PWM_Yaw.h"

static PWM_Yaw_backupStruct PWM_Yaw_backup;


/*******************************************************************************
* Function Name: PWM_Yaw_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  PWM_Yaw_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void PWM_Yaw_SaveConfig(void) 
{

    #if(!PWM_Yaw_UsingFixedFunction)
        #if(!PWM_Yaw_PWMModeIsCenterAligned)
            PWM_Yaw_backup.PWMPeriod = PWM_Yaw_ReadPeriod();
        #endif /* (!PWM_Yaw_PWMModeIsCenterAligned) */
        PWM_Yaw_backup.PWMUdb = PWM_Yaw_ReadCounter();
        #if (PWM_Yaw_UseStatus)
            PWM_Yaw_backup.InterruptMaskValue = PWM_Yaw_STATUS_MASK;
        #endif /* (PWM_Yaw_UseStatus) */

        #if(PWM_Yaw_DeadBandMode == PWM_Yaw__B_PWM__DBM_256_CLOCKS || \
            PWM_Yaw_DeadBandMode == PWM_Yaw__B_PWM__DBM_2_4_CLOCKS)
            PWM_Yaw_backup.PWMdeadBandValue = PWM_Yaw_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(PWM_Yaw_KillModeMinTime)
             PWM_Yaw_backup.PWMKillCounterPeriod = PWM_Yaw_ReadKillTime();
        #endif /* (PWM_Yaw_KillModeMinTime) */

        #if(PWM_Yaw_UseControl)
            PWM_Yaw_backup.PWMControlRegister = PWM_Yaw_ReadControlRegister();
        #endif /* (PWM_Yaw_UseControl) */
    #endif  /* (!PWM_Yaw_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PWM_Yaw_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  PWM_Yaw_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_Yaw_RestoreConfig(void) 
{
        #if(!PWM_Yaw_UsingFixedFunction)
            #if(!PWM_Yaw_PWMModeIsCenterAligned)
                PWM_Yaw_WritePeriod(PWM_Yaw_backup.PWMPeriod);
            #endif /* (!PWM_Yaw_PWMModeIsCenterAligned) */

            PWM_Yaw_WriteCounter(PWM_Yaw_backup.PWMUdb);

            #if (PWM_Yaw_UseStatus)
                PWM_Yaw_STATUS_MASK = PWM_Yaw_backup.InterruptMaskValue;
            #endif /* (PWM_Yaw_UseStatus) */

            #if(PWM_Yaw_DeadBandMode == PWM_Yaw__B_PWM__DBM_256_CLOCKS || \
                PWM_Yaw_DeadBandMode == PWM_Yaw__B_PWM__DBM_2_4_CLOCKS)
                PWM_Yaw_WriteDeadTime(PWM_Yaw_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(PWM_Yaw_KillModeMinTime)
                PWM_Yaw_WriteKillTime(PWM_Yaw_backup.PWMKillCounterPeriod);
            #endif /* (PWM_Yaw_KillModeMinTime) */

            #if(PWM_Yaw_UseControl)
                PWM_Yaw_WriteControlRegister(PWM_Yaw_backup.PWMControlRegister);
            #endif /* (PWM_Yaw_UseControl) */
        #endif  /* (!PWM_Yaw_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: PWM_Yaw_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  PWM_Yaw_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void PWM_Yaw_Sleep(void) 
{
    #if(PWM_Yaw_UseControl)
        if(PWM_Yaw_CTRL_ENABLE == (PWM_Yaw_CONTROL & PWM_Yaw_CTRL_ENABLE))
        {
            /*Component is enabled */
            PWM_Yaw_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            PWM_Yaw_backup.PWMEnableState = 0u;
        }
    #endif /* (PWM_Yaw_UseControl) */

    /* Stop component */
    PWM_Yaw_Stop();

    /* Save registers configuration */
    PWM_Yaw_SaveConfig();
}


/*******************************************************************************
* Function Name: PWM_Yaw_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  PWM_Yaw_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void PWM_Yaw_Wakeup(void) 
{
     /* Restore registers values */
    PWM_Yaw_RestoreConfig();

    if(PWM_Yaw_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        PWM_Yaw_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
