/*******************************************************************************
* File Name: Qd_Yaw_PM.c
* Version 3.0
*
* Description:
*  This file contains the setup, control and status commands to support 
*  component operations in low power mode.  
*
* Note:
*  None.
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Qd_Yaw.h"

static Qd_Yaw_BACKUP_STRUCT Qd_Yaw_backup = {0u};


/*******************************************************************************
* Function Name: Qd_Yaw_SaveConfig
********************************************************************************
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Qd_Yaw_SaveConfig(void) 
{
    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT)
        Qd_Yaw_Cnt8_SaveConfig();
    #else 
        /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT) || 
         * (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT)
         */
        Qd_Yaw_Cnt16_SaveConfig();
    #endif /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT) */
}


/*******************************************************************************
* Function Name: Qd_Yaw_RestoreConfig
********************************************************************************
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Qd_Yaw_RestoreConfig(void) 
{
    #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT)
        Qd_Yaw_Cnt8_RestoreConfig();
    #else 
        /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT) || 
         * (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT) 
         */
        Qd_Yaw_Cnt16_RestoreConfig();
    #endif /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT) */
}


/*******************************************************************************
* Function Name: Qd_Yaw_Sleep
********************************************************************************
* 
* Summary:
*  Prepare Quadrature Decoder Component goes to sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Qd_Yaw_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Qd_Yaw_Sleep(void) 
{
    if (0u != (Qd_Yaw_SR_AUX_CONTROL & Qd_Yaw_INTERRUPTS_ENABLE))
    {
        Qd_Yaw_backup.enableState = 1u;
    }
    else /* The Quadrature Decoder Component is disabled */
    {
        Qd_Yaw_backup.enableState = 0u;
    }

    Qd_Yaw_Stop();
    Qd_Yaw_SaveConfig();
}


/*******************************************************************************
* Function Name: Qd_Yaw_Wakeup
********************************************************************************
*
* Summary:
*  Prepare Quadrature Decoder Component to wake up.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Qd_Yaw_backup - used when non-retention registers are restored.
*
*******************************************************************************/
void Qd_Yaw_Wakeup(void) 
{
    Qd_Yaw_RestoreConfig();

    if (Qd_Yaw_backup.enableState != 0u)
    {
        #if (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT)
            Qd_Yaw_Cnt8_Enable();
        #else 
            /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_16_BIT) || 
            *  (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_32_BIT) 
            */
            Qd_Yaw_Cnt16_Enable();
        #endif /* (Qd_Yaw_COUNTER_SIZE == Qd_Yaw_COUNTER_SIZE_8_BIT) */

        /* Enable component's operation */
        Qd_Yaw_Enable();
    } /* Do nothing if component's block was disabled before */
}


/* [] END OF FILE */

