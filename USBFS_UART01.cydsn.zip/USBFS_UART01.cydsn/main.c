#include <project.h>
#include "stdio.h"    

/* Used to set the ADC count properly between 0-255 */

//#if defined (__GNUC__)
    /* Add an explicit reference to the floating point printf library */
    /* to allow usage of the floating point conversion specifiers. */
    /* This is not linked in by default with the newlib-nano library. */
//    asm (".global _printf_float");
//#endif

#define USBFS_DEVICE    (0u)

/* The buffer size is equal to the maximum packet size of the IN and OUT bulk
* endpoints.
*/
#define USBUART_BUFFER_SIZE (64u)
#define LINE_STR_LENGTH     (20u)

int PWMSend;
int PositionSend;
int AngleSend;

void Send(uint16 Pwm, uint16 Pos, uint16 Ang)
{                   
    char Msg[50] = {};
    sprintf(Msg,"%d;%d;%d \r\n",Pwm,Pos,Ang);
    
    USBUART_PutString(Msg);        
}

CY_ISR(InterruptTimer){
    Timer_WritePeriod(500000);
    
    Send(PWMSend,PositionSend,AngleSend);
}
int main()
{
    uint16 count;
    uint8 buffer[USBUART_BUFFER_SIZE];
    
    uint16 Encoder_count;
    uint16 Angle_signal;
    
    uint16 Position;
    uint16 Angle;
    uint16 PWM;
    
    #if (CY_PSOC3 || CY_PSOC5LP)
        ADC_AngEncoder_Start(); 
        Timer_Start();
        QuadDec_Start();
        PWM_Motor_Start();
    #endif
        CyGlobalIntEnable;

    /* Start USBFS operation with 5-V operation. */
    USBUART_Start(USBFS_DEVICE, USBUART_5V_OPERATION);
    isr_1_StartEx(InterruptTimer);
    ADC_AngEncoder_StartConvert(); 
    
    while(1)
    {
        /* Wait for end of conversion */
        ADC_AngEncoder_IsEndConversion(ADC_AngEncoder_WAIT_FOR_RESULT); 
        
        Angle_signal = ADC_AngEncoder_GetResult16();
        Angle = Angle_signal;
        //Acquire QuadDec data
        Encoder_count = QuadDec_GetCounter();
        
        Position = Encoder_count;
        /////////////////////////////////////////////////////////////
        
        //Determine Angle & Position
        
        /////////////////////////////////////////////////////////////
                
        PWM = PWM_Out_Motor_Read();
        
        /* Host can send double SET_INTERFACE request. */
        if (0u != USBUART_IsConfigurationChanged())
        {
            /* Initialize IN endpoints when device is configured. */
            if (0u != USBUART_GetConfiguration())
            {
                /* Enumeration is done, enable OUT endpoint to receive data 
                 * from host. */
                USBUART_CDC_Init();
            }
        }

        /* Service USB CDC when device is configured. */
        if (0u != USBUART_GetConfiguration())
        {
            /* Check for input data from host. */
            //if (0u != USBUART_DataIsReady())
            if(1)
            {
                /* Read received data and re-enable OUT endpoint. */
                count = USBUART_GetAll(buffer);

                if (0u != count)
                {
                    /* Wait until component is ready to send data to host. */
                    while (0u == USBUART_CDCIsReady())
                    {
                    }
                    
                    /* Send data back to host. */
                    PWMSend= PWM;
                    PositionSend = Position;
                    AngleSend = Angle;

                    if (USBUART_BUFFER_SIZE == count)
                    {
                        /* Wait until component is ready to send data to PC. */
                        while (0u == USBUART_CDCIsReady())
                        {
                        }                        
                    }
                }
            }
        }
    }
}


/* [] END OF FILE */
